<?
require_once($_SERVER["DOCUMENT_ROOT"]."/INC/dbConn.php");
require_once($_SERVER["DOCUMENT_ROOT"]."/INC/get_session.php");
require_once($_SERVER["DOCUMENT_ROOT"]."/INC/function.php");
require_once($_SERVER["DOCUMENT_ROOT"]."/INC/func_other.php");

@extract($_GET);
@extract($_POST);
?>
